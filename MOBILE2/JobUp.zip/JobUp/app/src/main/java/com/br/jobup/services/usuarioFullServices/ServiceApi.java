package com.br.jobup.services.usuarioFullServices;

/**
 * Created by luizramos on 28/04/17.
 */

public interface ServiceApi {
}
