package com.br.jobup.validations;

import java.util.UUID;

/**
 * Created by luizramos on 13/04/17.
 */

public class Util {

    public static String getUUID(){
        return UUID.randomUUID().toString();
    }
}
